#!/bin/sh

rcK()
{
	for i in $(ls /oem/usr/etc/init.d/S??*) ;do

		# Ignore dangling symlinks (if any).
		[ ! -f "$i" ] && continue

		case "$i" in
			*.sh)
				# Source shell script for speed.
				(
					trap - INT QUIT TSTP
					set stop
					. $i
				)
				;;
			*)
				# No sh extension, so fork subprocess.
				$i stop
				;;
		esac
	done
}

echo "Stop Application ..."
killall sample_demo_aiisp
killall udhcpc

cnt=0
while [ 1 ];
do
	sleep 1
	cnt=$(( cnt + 1 ))
	if [ $cnt -eq 8 ]; then
		echo "killall -9 sample_demo_aiisp"
		killall -9 sample_demo_aiisp
		sleep 0.1
		break
	fi
	ps|grep sample_demo_aiisp|grep -v grep
	if [ $? -ne 0 ]; then
		echo "sample_demo_aiisp exit"
		break
	else
		echo "sample_demo_aiisp active"
	fi
done

rcK
