// Copyright 2023 Rockchip Electronics Co., Ltd. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "rockit.h"

RK_S32 rockit_init_vo(ROCKIT_VO_CFG *stVoCfg) {
    RK_S32 s32Ret = RK_SUCCESS;

    stVoCfg->devId = 0;
    stVoCfg->VoLayer = 0;
    stVoCfg->u32VoChn = 0;

    stVoCfg->VoPubAttr.enIntfType = VO_INTF_DEFAULT;
    stVoCfg->VoPubAttr.enIntfSync = VO_OUTPUT_DEFAULT;

    return s32Ret;
}

RK_S32 rockit_create_vo(ROCKIT_VO_CFG *stVoCfg) {
    RK_S32 ret;

    ret = RK_MPI_VO_SetPubAttr(stVoCfg->devId, &stVoCfg->VoPubAttr);
    if (ret != RK_SUCCESS) {
        printf("RK_MPI_VO_SetPubAttr %x\n", ret);
        return ret;
    }
    printf("RK_MPI_VO_SetPubAttr success\n");

    ret = RK_MPI_VO_Enable(stVoCfg->devId);
    if (ret != RK_SUCCESS) {
        printf("RK_MPI_VO_Enable err is %x\n", ret);
        return ret;
    }
    printf("RK_MPI_VO_Enable success\n");

    ret = RK_MPI_VO_GetLayerDispBufLen(stVoCfg->VoLayer, &stVoCfg->u32DispBufLen);
    if (ret != RK_SUCCESS) {
        printf("Get display buf len failed with error code %d!\n", ret);
        return ret;
    }
    printf("Get VoLayer %d disp buf len is %d.\n", stVoCfg->VoLayer, stVoCfg->u32DispBufLen);

    stVoCfg->u32DispBufLen = 2;
    ret = RK_MPI_VO_SetLayerDispBufLen(stVoCfg->VoLayer, stVoCfg->u32DispBufLen);
    if (ret != RK_SUCCESS) {
        return ret;
    }
    printf("Agin Get VoLayer %d disp buf len is %d.\n", stVoCfg->VoLayer, stVoCfg->u32DispBufLen);

    /* get vo attribute*/
    ret = RK_MPI_VO_GetPubAttr(stVoCfg->devId, &stVoCfg->VoPubAttr);
    if (ret) {
        printf("RK_MPI_VO_GetPubAttr fail!\n");
        return ret;
    }
    printf("RK_MPI_VO_GetPubAttr success\n");

    if ((stVoCfg->VoPubAttr.stSyncInfo.u16Hact == 0) || (stVoCfg->VoPubAttr.stSyncInfo.u16Vact == 0)) {
        if (stVoCfg->devId == 0) {
            stVoCfg->VoPubAttr.stSyncInfo.u16Hact = 1024;
            stVoCfg->VoPubAttr.stSyncInfo.u16Vact = 600;
        } else {
            stVoCfg->VoPubAttr.stSyncInfo.u16Hact = 600;
            stVoCfg->VoPubAttr.stSyncInfo.u16Vact = 1024;
        }
    }

    stVoCfg->stLayerAttr.stDispRect.s32X = 0;
    stVoCfg->stLayerAttr.stDispRect.s32Y = 0;
    stVoCfg->stLayerAttr.stDispRect.u32Width = stVoCfg->VoPubAttr.stSyncInfo.u16Hact;
    stVoCfg->stLayerAttr.stDispRect.u32Height = stVoCfg->VoPubAttr.stSyncInfo.u16Vact;
    stVoCfg->stLayerAttr.stImageSize.u32Width = stVoCfg->VoPubAttr.stSyncInfo.u16Hact;
    stVoCfg->stLayerAttr.stImageSize.u32Height = stVoCfg->VoPubAttr.stSyncInfo.u16Vact;
    printf("stLayerAttr W=%d, H=%d\n", stVoCfg->stLayerAttr.stDispRect.u32Width,
                stVoCfg->stLayerAttr.stDispRect.u32Height);

    stVoCfg->stLayerAttr.u32DispFrmRt = 25;
    stVoCfg->stLayerAttr.enPixFormat = RK_FMT_BGRA8888;
    stVoCfg->VideoCSC.enCscMatrix = VO_CSC_MATRIX_IDENTITY;
    stVoCfg->VideoCSC.u32Contrast = 50;
    stVoCfg->VideoCSC.u32Hue = 50;
    stVoCfg->VideoCSC.u32Luma = 50;
    stVoCfg->VideoCSC.u32Satuature = 50;

    ret = RK_MPI_VO_BindLayer(stVoCfg->VoLayer, stVoCfg->devId, VO_LAYER_MODE_GRAPHIC);
    if (ret != RK_SUCCESS) {
        printf("RK_MPI_VO_BindLayer VoLayer = %d error\n", stVoCfg->VoLayer);
        return ret;
    }
    printf("RK_MPI_VO_BindLayer success\n");

    ret = RK_MPI_VO_SetLayerAttr(stVoCfg->VoLayer, &stVoCfg->stLayerAttr);
    if (ret != RK_SUCCESS) {
        printf("RK_MPI_VO_SetLayerAttr VoLayer = %d error\n", stVoCfg->VoLayer);
        return ret;
    }
    printf("RK_MPI_VO_SetLayerAttr success\n");

    RK_MPI_VO_SetLayerSpliceMode(stVoCfg->VoLayer, VO_SPLICE_MODE_RGA);

    ret = RK_MPI_VO_EnableLayer(stVoCfg->VoLayer);
    if (ret != RK_SUCCESS) {
        printf("RK_MPI_VO_EnableLayer VoLayer = %d error\n", stVoCfg->VoLayer);
        return ret;
    }
    printf("RK_MPI_VO_EnableLayer success\n");

    ret = RK_MPI_VO_SetLayerCSC(stVoCfg->VoLayer, &stVoCfg->VideoCSC);
    if (ret != RK_SUCCESS) {
        printf("RK_MPI_VO_SetLayerCSC error\n");
        return ret;
    }
    printf("RK_MPI_VO_SetLayerCSC success\n");

    ret = RK_MPI_VO_EnableChn(stVoCfg->VoLayer, stVoCfg->u32VoChn);
    if (ret != RK_SUCCESS) {
        printf("create layer %d ch vo failed!\n", stVoCfg->u32VoChn);
        return ret;
    }
    printf("RK_MPI_VO_EnableChn success\n");

    stVoCfg->VoChnAttr.bDeflicker = RK_FALSE;
    stVoCfg->VoChnAttr.u32Priority = 1;
    stVoCfg->VoChnAttr.stRect.s32X = 0;
    stVoCfg->VoChnAttr.stRect.s32Y = 0;
    stVoCfg->VoChnAttr.stRect.u32Width = stVoCfg->stLayerAttr.stDispRect.u32Width;
    stVoCfg->VoChnAttr.stRect.u32Height = stVoCfg->stLayerAttr.stDispRect.u32Height;
    ret = RK_MPI_VO_SetChnAttr(stVoCfg->VoLayer, stVoCfg->u32VoChn, &stVoCfg->VoChnAttr);
    if (ret != RK_SUCCESS) {
        printf("create layer %d ch vo failed!\n", stVoCfg->u32VoChn);
        return ret;
    }
    return ret;
}

RK_S32 rockit_start_vo(ROCKIT_VO_CFG *stVoCfg) {
    RK_S32 ret = RK_FAILURE;
    RK_VOID *pMblk;
    RK_S32 u32BuffSize;
    RK_S32 lcd_w, lcd_h;

    lcd_w = stVoCfg->stLayerAttr.stImageSize.u32Width;
    lcd_h = stVoCfg->stLayerAttr.stImageSize.u32Height;
    u32BuffSize = RK_MPI_VO_CreateGraphicsFrameBuffer(lcd_w, lcd_h, RK_FMT_BGRA8888, &pMblk);
    if (u32BuffSize == 0) {
        printf("can not create graphics frame buffer\n");
        return ret;
    }

    stVoCfg->vo_fd = RK_MPI_MB_Handle2Fd(pMblk);
    stVoCfg->stVFrame.stVFrame.u32Width = lcd_w;
    stVoCfg->stVFrame.stVFrame.u32Height = lcd_h;
    stVoCfg->stVFrame.stVFrame.u32VirWidth = lcd_w;
    stVoCfg->stVFrame.stVFrame.u32VirHeight = lcd_h;
    stVoCfg->stVFrame.stVFrame.enPixelFormat = RK_FMT_BGRA8888;
    stVoCfg->stVFrame.stVFrame.pMbBlk = pMblk;

    return RK_SUCCESS;
}

RK_S32 rockit_destroy_vo(ROCKIT_VO_CFG *stVoCfg) {
    RK_S32 ret = RK_SUCCESS;

    RK_MPI_VO_DestroyGraphicsFrameBuffer(stVoCfg->stVFrame.stVFrame.pMbBlk);

    ret = RK_MPI_VO_DisableChn(stVoCfg->VoLayer, stVoCfg->u32VoChn);
    if (ret != RK_SUCCESS) {
        RK_LOGE("RK_MPI_VO_DisableChn failed, ret = %x", ret);
        return ret;
    }

    ret = RK_MPI_VO_DisableLayer(stVoCfg->VoLayer);
    if (ret != RK_SUCCESS) {
        RK_LOGE("RK_MPI_VO_DisableLayer failed, ret = %x", ret);
        return ret;
    }

    ret = RK_MPI_VO_UnBindLayer(stVoCfg->VoLayer, stVoCfg->devId);
    if (ret != RK_SUCCESS) {
        RK_LOGE("RK_MPI_VO_UnBindLayer failed, ret = %x", ret);
        return ret;
    }

    ret = RK_MPI_VO_Disable(stVoCfg->devId);
    if (ret != RK_SUCCESS) {
        RK_LOGE("RK_MPI_VO_Disable failed, ret = %x", ret);
        return ret;
    }

    RK_MPI_VO_CloseFd();

    return ret;
}

void rockit_get_vo_resolve(RK_S32 pipe_id, RK_S32 *width, RK_S32 *height) {
    *width = ctx->stVoCfg[pipe_id].stLayerAttr.stImageSize.u32Width;
    *height = ctx->stVoCfg[pipe_id].stLayerAttr.stImageSize.u32Height;
    return;
}

RK_S32 rockit_get_vo_fd(RK_S32 pipe_id) {
    return ctx->stVoCfg[pipe_id].vo_fd;
}

VIDEO_FRAME_INFO_S rockit_get_vo_frame(RK_S32 pipe_id) {
    return ctx->stVoCfg[pipe_id].stVFrame;
}
