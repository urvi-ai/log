// Copyright 2022 Rockchip Electronics Co., Ltd. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "rockit.h"

/*
 * VI ---> VENC (RTSP or tuya)
 */
RK_S32 rockit_pipe0_init(ROCKIT_CTX_S *ctx) {
    RK_S32 s32Ret = RK_SUCCESS;

    s32Ret = rockit_init_vi(&ctx->stViCfg[0]);
    if (s32Ret) {
        RK_LOGE("init vi failed: %d", s32Ret);
        return s32Ret;
    }

    s32Ret = rockit_init_venc(&ctx->stVencCfg[0]);
    if (s32Ret) {
        RK_LOGE("init venc failed: %d", s32Ret);
        return s32Ret;
    }

    if (ctx->stVencCfg[0].sendRtsp == RK_TRUE)
        rockit_rtsp_init();

    return s32Ret;
}

RK_S32 rockit_pipe0_bind(ROCKIT_CTX_S *ctx) {
    RK_S32 s32Ret = RK_FAILURE;
    MPP_CHN_S stViChn, stVencChn;

    stViChn.enModId = RK_ID_VI;
    stViChn.s32DevId = ctx->stViCfg[0].devId;
    stViChn.s32ChnId = ctx->stViCfg[0].channelId;

    stVencChn.enModId = RK_ID_VENC;
    stVencChn.s32DevId = 0;
    stVencChn.s32ChnId = ctx->stVencCfg[0].u32ChnId;

    s32Ret = RK_MPI_SYS_Bind(&stViChn, &stVencChn);
    if (s32Ret != RK_SUCCESS) {
        RK_LOGE("bind %d channel vi and venc failed", stViChn.s32ChnId);
        return s32Ret;
    }

    return s32Ret;
}

RK_S32 rockit_pipe0_unbind(ROCKIT_CTX_S *ctx) {
    RK_S32 s32Ret = RK_FAILURE;
    MPP_CHN_S stViChn, stVencChn;

    stViChn.enModId = RK_ID_VI;
    stViChn.s32DevId = ctx->stViCfg[0].devId;
    stViChn.s32ChnId = ctx->stViCfg[0].channelId;

    stVencChn.enModId = RK_ID_VENC;
    stVencChn.s32DevId = 0;
    stVencChn.s32ChnId = ctx->stVencCfg[0].u32ChnId;

    s32Ret = RK_MPI_SYS_UnBind(&stViChn, &stVencChn);
    if (s32Ret != RK_SUCCESS) {
        RK_LOGE("unbind %d channel vi and venc failed", stViChn.s32ChnId);
        return s32Ret;
    }

    return s32Ret;
}

RK_S32 rockit_pipe0_create(ROCKIT_CTX_S *ctx) {
    RK_S32 s32Ret = RK_SUCCESS;

    rockit_create_vi(ctx->stViCfg[0]);
    rockit_create_venc(ctx->stVencCfg[0]);

    s32Ret = rockit_pipe0_bind(ctx);
    if (s32Ret) {
        RK_LOGE("bind vi venc failed: %d", s32Ret);
        return s32Ret;
    }

    rockit_start_venc(&ctx->stVencCfg[0]);

    return s32Ret;
}

RK_S32 rockit_pipe0_destroy(ROCKIT_CTX_S *ctx) {
    RK_S32 s32Ret = RK_SUCCESS;

    while (ctx->stVencCfg[0].vencTaskEnd != RK_TRUE) {
        usleep(1000llu);
    }

    s32Ret = rockit_pipe0_unbind(ctx);
    if (s32Ret) {
        RK_LOGE("unbind vi venc failed: %d", s32Ret);
        return s32Ret;
    }

    s32Ret = rockit_destroy_vi(ctx->stViCfg[0]);
    if (s32Ret) {
        RK_LOGE("destroy vi failed: %d", s32Ret);
        return s32Ret;
    }

    s32Ret = rockit_destroy_venc(ctx->stVencCfg[0]);
    if (s32Ret) {
        RK_LOGE("destroy venc failed: %d", s32Ret);
        return s32Ret;
    }

    if (ctx->stVencCfg[0].sendRtsp == RK_TRUE)
        rockit_rtsp_deinit();

    return s32Ret;
}

int rockit_pipe_rtsp_start(int dev_id) {
    RK_S32 s32Ret = RK_SUCCESS;

    if (!ctx) {
        ctx = (ROCKIT_CTX_S *)(malloc(sizeof(ROCKIT_CTX_S)));
        if (!ctx) {
            RK_LOGE("malloc ROCKIT_CTX_S memory failed");
            return -1;
        }
        memset(ctx, 0, sizeof(ROCKIT_CTX_S));
    } else {
        memset(&ctx->stViCfg[0], 0, sizeof(ctx->stViCfg[0]));
        memset(&ctx->stVencCfg[0], 0, sizeof(ctx->stVencCfg[0]));
    }

    ctx->stViCfg[0].devId = dev_id;
    ctx->stViCfg[0].pipeId = ctx->stViCfg[0].devId;
    ctx->stViCfg[0].channelId = 0;
    memcpy(ctx->stViCfg[0].stChnAttr.stIspOpt.aEntityName, "rkisp_mainpath", strlen("rkisp_mainpath"));
    ctx->stViCfg[0].stChnAttr.stSize.u32Width = 1920;
    ctx->stViCfg[0].stChnAttr.stSize.u32Height = 1080;

    ctx->stVencCfg[0].u32ChnId = 0;
    ctx->stVencCfg[0].u32DstCodec = RK_VIDEO_ID_AVC;
    ctx->stVencCfg[0].u32SrcWidth = ctx->stViCfg[0].stChnAttr.stSize.u32Width;
    ctx->stVencCfg[0].u32SrcHeight = ctx->stViCfg[0].stChnAttr.stSize.u32Height;
    ctx->stVencCfg[0].u32srcVirWidth = ctx->stViCfg[0].stChnAttr.stSize.u32Width;
    ctx->stVencCfg[0].u32srcVirHeight = ctx->stViCfg[0].stChnAttr.stSize.u32Height;
    ctx->stVencCfg[0].enRcMode = VENC_RC_MODE_H264CBR;
    ctx->stVencCfg[0].u32BitRateKb = 1 * 1024;
    ctx->stVencCfg[0].u32FixQp = 0;// valid when rc_mode is fixqp
    ctx->stVencCfg[0].bSuperFrm = RK_FALSE;
    ctx->stVencCfg[0].enGopMode = VENC_GOPMODE_NORMALP;
    ctx->stVencCfg[0].u32GopSize = 60;
    ctx->stVencCfg[0].venc_func = rockit_venc_get_stream;
    ctx->stVencCfg[0].loopCount = 0;
    ctx->stVencCfg[0].sendRtsp = RK_TRUE;
    //ctx->stVencCfg[0].dstFilePath = "/tmp/";

    s32Ret = rockit_pipe0_init(ctx);
    if (s32Ret) {
        RK_LOGI("rockit_pipe0_init failed: %d!", s32Ret);
        goto __FAILED;
    }

    s32Ret = rockit_pipe0_create(ctx);
    if (s32Ret) {
        RK_LOGI("rockit_pipe0_create failed: %d!", s32Ret);
        goto __FAILED;
    }

    s32Ret = rockit_pipe0_destroy(ctx);
    if (s32Ret) {
        RK_LOGI("rockit_pipe0_destroy failed: %d!", s32Ret);
        goto __FAILED;
    }

__FAILED:

    return s32Ret;
}

void rockit_pipe_rtsp_stop(void) {
    ctx->stVencCfg[0].loopCount = -1;
}

int rockit_pipe_get_video(int dev_id) {
    RK_S32 s32Ret = RK_SUCCESS;

    if (!ctx) {
        ctx = (ROCKIT_CTX_S *)(malloc(sizeof(ROCKIT_CTX_S)));
        if (!ctx) {
            RK_LOGE("malloc ROCKIT_CTX_S memory failed");
            return -1;
        }
        memset(ctx, 0, sizeof(ROCKIT_CTX_S));
    } else {
        memset(&ctx->stViCfg[1], 0, sizeof(ctx->stViCfg[1]));
        memset(&ctx->stVencCfg[1], 0, sizeof(ctx->stVencCfg[1]));
        memset(&ctx->stVoCfg[1], 0, sizeof(ctx->stVoCfg[1]));
    }

    ctx->stViCfg[1].devId = dev_id;
    ctx->stViCfg[1].pipeId = ctx->stViCfg[1].devId;
    ctx->stViCfg[1].channelId = 1;
    ctx->stViCfg[1].stChnAttr.stSize.u32Width = 1920;
    ctx->stViCfg[1].stChnAttr.stSize.u32Height = 1080;
    ctx->stViCfg[1].loopCountSet = 1000;

    s32Ret = rockit_init_vi(&ctx->stViCfg[1]);
    if (s32Ret) {
        RK_LOGE("init vi failed: %d", s32Ret);
        return s32Ret;
    }

    s32Ret = rockit_create_vi(ctx->stViCfg[1]);
    if (s32Ret) {
        RK_LOGE("create vi failed: %d", s32Ret);
        return s32Ret;
    }

    s32Ret = rockit_start_vi(ctx->stViCfg[1]);
    if (s32Ret) {
        RK_LOGE("start vi failed: %d", s32Ret);
        return s32Ret;
    }
}

int rockit_pipe_start_vo()
{
#ifdef USE_VO
    RK_S32 s32Ret = RK_SUCCESS;
    
   if (!ctx) {
        ctx = (ROCKIT_CTX_S *)(malloc(sizeof(ROCKIT_CTX_S)));
        if (!ctx) {
            RK_LOGE("malloc ROCKIT_CTX_S memory failed");
            return -1;
        }
        memset(ctx, 0, sizeof(ROCKIT_CTX_S));
    } else {
        memset(&ctx->stVoCfg[1], 0, sizeof(ctx->stVoCfg[1]));
    }
    
    //vo
    s32Ret = rockit_init_vo(&ctx->stVoCfg[1]);
    if (s32Ret) {
        RK_LOGE("init vo failed: %d", s32Ret);
        return s32Ret;
    }

    s32Ret = rockit_create_vo(&ctx->stVoCfg[1]);
    if (s32Ret) {
        RK_LOGE("create vo failed: %d", s32Ret);
        return s32Ret;
    }
    s32Ret = rockit_start_vo(&ctx->stVoCfg[1]);
    if (s32Ret) {
        RK_LOGE("start vo failed: %d", s32Ret);
        return s32Ret;
    }
#endif
    return s32Ret;
}

void rockit_pipe_stop_video(int dev_id) {
#ifdef USE_VO
    //stop vo
    rockit_destroy_vo(&ctx->stVoCfg[1]);
#endif

    //stop vi
    RK_MPI_VI_DisableChn(dev_id, ctx->stViCfg[1].channelId);
    RK_MPI_VI_DisableDev(dev_id);
}
