// Copyright 2022 Rockchip Electronics Co., Ltd. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>
#include <fcntl.h>
#include <termios.h>

#include "rk_defines.h"
#include "rk_debug.h"
#include "rk_mpi_cal.h"
#include "rk_mpi_mb.h"
#include "rk_mpi_sys.h"
#include "rk_mpi_vi.h"
#include "rk_mpi_vo.h"
#include "rk_mpi_venc.h"
#include "rk_mpi_vdec.h"
#include "rk_mpi_vpss.h"
#include "rk_comm_video.h"
#include "rk_comm_aenc.h"
#include "rk_comm_vo.h"

#define USE_VO  1
//#define USE_DRM  1

#define IQFILE_PATH	"/etc/iqfiles/"

#define RK_ARRAY_ELEMS(a)      (sizeof(a) / sizeof((a)[0]))
#define RK_ALIGN(x, a)         (((x) + (a) - 1) & ~((a) - 1))
#define RK_ALIGN_16(x)         RK_ALIGN(x, 16)
#define RK_ALIGN_64(x)         RK_ALIGN(x, 64)
#define RK_ALIGN_256(x)        RK_ALIGN(x, 256)
#define RK_ALIGN_256_ODD(x)    (RK_ALIGN(x, 256) | 256)

typedef struct rk_rockit_vi_cfg {
    RK_S32 devId;
    RK_S32 pipeId;
    RK_S32 channelId;
    RK_S32 loopCountSet;
    RK_S32 selectFd;
    RK_BOOL bFreeze;
    COMPRESS_MODE_E enCompressMode;
    VI_DEV_ATTR_S stDevAttr;
    VI_DEV_BIND_PIPE_S stBindPipe;
    VI_CHN_ATTR_S stChnAttr;
    VI_SAVE_FILE_INFO_S stDebugFile;
    VIDEO_FRAME_INFO_S stViFrame;
    VI_CHN_STATUS_S stChnStatus;
} ROCKIT_VI_CFG;

typedef struct rk_rockit_venc_cfg {
    RK_U32 u32ChnId;
    RK_U32 u32SrcWidth;
    RK_U32 u32SrcHeight;
    RK_U32 u32srcVirWidth;
    RK_U32 u32srcVirHeight;
    RK_U32 u32ChNum;
    PIXEL_FORMAT_E enSrcPixFormat;
    RK_U32 u32DstCodec;
    RK_U32 u32BufferSize;
    RK_U32 u32StreamBufCnt;
    RK_U32 u32BitRateKb;
    RK_U32 u32GopSize;
    RK_U32 u32RoiTestCount;
    RK_U32 u32FixQp;
    RK_S32 s32SnapPicCount;
    MB_POOL vencPool;
    RK_BOOL bFrameRate;
    RK_BOOL bInsertUserData;
    COMPRESS_MODE_E enCompressMode;
    VENC_RC_MODE_E enRcMode;
    VENC_GOP_MODE_E enGopMode;
    VENC_CROP_TYPE_E enCropType;
    ROTATION_E enRotation;
    MIRROR_E enMirror;
    RK_BOOL bSuperFrm;
    RK_BOOL bFrmLost;
    RK_BOOL bIntraRefresh;
    RK_BOOL bHierarchicalQp;
    RK_BOOL bMjpegParam;
    RK_BOOL bForceIdr;
    RK_BOOL bFullRange;
    pthread_t pGetStreamThread;
    RK_BOOL threadExit;
    RK_BOOL vencTaskEnd;
    void *(*venc_func)(void *);
    const char *dstFilePath;
    RK_BOOL sendRtsp;
    RK_S32 loopCount;
} ROCKIT_VENC_CFG;

typedef struct rk_rockit_vo_cfg {
    RK_S32 devId;
    RK_S32 VoLayer;
    RK_S32 u32VoChn;
    RK_S32 u32DispBufLen;
    VO_PUB_ATTR_S VoPubAttr;
    VO_VIDEO_LAYER_ATTR_S stLayerAttr;
    VO_CSC_S VideoCSC;
    VO_CHN_ATTR_S VoChnAttr;
    VIDEO_FRAME_INFO_S stVFrame;
    RK_S32 vo_fd;
} ROCKIT_VO_CFG;

typedef struct rk_rockit_vpss_cfg {
    RK_U32 u32GrpId;
    RK_U32 u32ChnId[VPSS_MAX_CHN_NUM];
    RK_U32 u32VpssChnCnt;
    RK_BOOL bMirror;
    RK_BOOL bFlip;
    ROTATION_E rotation;
    VPSS_GRP_ATTR_S stGrpVpssAttr;
    VPSS_CHN_ATTR_S stVpssChnAttr[VPSS_MAX_CHN_NUM];
} ROCKIT_VPSS_CFG;

typedef struct rk_rockit_ctx {
    ROCKIT_VI_CFG stViCfg[3];
    ROCKIT_VENC_CFG stVencCfg[3];
    ROCKIT_VO_CFG stVoCfg[2];
    ROCKIT_VPSS_CFG stVpssCfg;
} ROCKIT_CTX_S;

ROCKIT_CTX_S *ctx;

RK_S32 rockit_init_vi(ROCKIT_VI_CFG *stViCfg);
RK_S32 rockit_create_vi(ROCKIT_VI_CFG stViCfg);
RK_S32 rockit_start_vi(ROCKIT_VI_CFG stViCfg);
RK_S32 rockit_destroy_vi(ROCKIT_VI_CFG stViCfg);

RK_S32 rockit_init_vo(ROCKIT_VO_CFG *stVoCfg);
RK_S32 rockit_create_vo(ROCKIT_VO_CFG *stVoCfg);
RK_S32 rockit_start_vo(ROCKIT_VO_CFG *stVoCfg);
RK_S32 rockit_destroy_vo(ROCKIT_VO_CFG *stVoCfg);
void rockit_get_vo_resolve(RK_S32 pipe_id, RK_S32 *width, RK_S32 *height);
RK_S32 rockit_get_vo_fd(RK_S32 pipe_id);
VIDEO_FRAME_INFO_S rockit_get_vo_frame(RK_S32 pipe_id);

RK_S32 rockit_init_vpss(ROCKIT_CTX_S *ctx);
RK_S32 rockit_create_vpss(ROCKIT_VPSS_CFG stVpssCfg);
RK_S32 rockit_destroy_vpss(ROCKIT_VPSS_CFG stVpssCfg);

RK_S32 rockit_init_venc(ROCKIT_VENC_CFG *stVencCfg);
RK_S32 rockit_create_venc(ROCKIT_VENC_CFG stVencCfg);
RK_S32 rockit_start_venc(ROCKIT_VENC_CFG *stVencCfg);
RK_S32 rockit_destroy_venc(ROCKIT_VENC_CFG stVencCfg);
void* rockit_venc_get_stream(void *pArgs);

int rockit_pipe_rtsp_start(int dev_id);
void rockit_pipe_rtsp_stop(void);
int rockit_pipe_get_video(int dev_id);
void rockit_pipe_stop_video(int dev_id);
int rockit_pipe_start_vo();

void rockit_rtsp_init();
void rockit_rtsp_deinit();
void rockit_rtsp_send_live0(void *data, RK_U32 u32Len, RK_U64 u64PTS);

int uvc_start();
int uvc_stop(void);
