// Copyright 2022 Rockchip Electronics Co., Ltd. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <signal.h>
#include "isp.h"
#include "rockit.h"
#include "ui_main.h"

static int g_main_run_ = 1;

/*
 *default GC2093 is 1
 */
int g_sensor_id = 1; 

/*
 *IM_HAL_TRANSFORM_ROT_90     = 1 << 0,
 *IM_HAL_TRANSFORM_ROT_180    = 1 << 1,
 *IM_HAL_TRANSFORM_ROT_270    = 1 << 2,
 */
int g_sensor_rotation = 1;

static void sig_proc(int signo) {
    RK_LOGE("received signo %d \n", signo);
    g_main_run_ = 0;
}

int main(int argc, char *argv[]) {
    int ret = 0;

    signal(SIGINT, sig_proc);

    if (RK_MPI_SYS_Init() != RK_SUCCESS) {
        return -1;
    }
    // already used rkaiq_3A_server init sensor
    // ret = rk_isp_init(dev_id, IQFILE_PATH);
    // if (ret) {
        // printf("rk_isp_init error");
        // return ret;
    // }

    ret = rockit_pipe_get_video(g_sensor_id);
    if (ret) {
        printf("rockit_pipe_get_video error");
        return ret;
    }
    
    ret = rockit_pipe_get_video(0); // 0 is GC2053, IR
    if (ret) {
        printf("rockit_pipe_get_video error");
        return ret;
    }

    ret = rockit_pipe_start_vo();
    if (ret) {
        printf("rockit_pipe_start_vo error");
        return ret;
    }

    // default preview rgb sensor
    ui_start(g_sensor_id, &g_main_run_);

    rockit_pipe_stop_video(1);
    rockit_pipe_stop_video(0);
    // rk_isp_deinit(dev_id); // use rkaiq_3A_server to init sensor, so not need deinit
    RK_MPI_SYS_Exit();
    return RK_SUCCESS;
}
