#ifndef __PREVIEW_H__
#define __PREVIEW_H__

void preview_start(void (*return_cb)(void));
void preview_stop(void);
void preview_set_sensor_id(int dev_id);

#endif
