#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <lvgl.h>
#include "lv_port_indev.h"
#include "setting.h"
#include "key.h"

static lv_img_dsc_t *img_bg = NULL;

static lv_obj_t *setting_main_bg_obj = NULL;
static void (*pReturn_cb)(void) = NULL;

static lv_img_dsc_t *create_bg(void)
{
    int i, j;
    lv_img_dsc_t* img_res = NULL;
    int *buff;

    img_res = malloc(sizeof(lv_img_dsc_t));
    memset(img_res, 0, sizeof(lv_img_dsc_t));
    img_res->header.always_zero = 0;
    img_res->header.w = LV_HOR_RES;
    img_res->header.h = LV_VER_RES;
    img_res->data_size = LV_HOR_RES * LV_VER_RES * LV_IMG_PX_SIZE_ALPHA_BYTE;
    img_res->header.cf = LV_IMG_CF_TRUE_COLOR_ALPHA;
    img_res->data = malloc(img_res->data_size);
    buff = img_res->data;
    for (i = 0; i < img_res->header.w * img_res->header.h; i++) {
        buff[i] = 0xff555555;
    }

    return img_res;
}

static void btn0_event_cb(lv_event_t * e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * btn = lv_event_get_target(e);
    if(code == LV_EVENT_CLICKED) {
        static uint8_t cnt = 0;
        cnt++;

        /*Get the first child of the button which is the label and change its text*/
        lv_obj_t * label = lv_obj_get_child(btn, 0);
        lv_label_set_text_fmt(label, "Button: %d", cnt);
    }
}

static void btn1_event_cb(lv_event_t * e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * btn = lv_event_get_target(e);
    if(code == LV_EVENT_CLICKED) {
        setting_stop();
    }
}

static void sw_event_handler(lv_event_t * e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * obj = lv_event_get_target(e);
    if(code == LV_EVENT_VALUE_CHANGED) {
        LV_LOG_USER("State: %s\n", lv_obj_has_state(obj, LV_STATE_CHECKED) ? "On" : "Off");
    }
}

void setting_start(void (*return_cb)(void))
{
    lv_obj_t *obj;
    lv_color_t outline_color;

    outline_color.full = 0xffff0000;

    pReturn_cb = return_cb;
    img_bg = create_bg();

    setting_main_bg_obj = obj = lv_img_create(lv_scr_act());
    lv_img_set_src(obj, img_bg);
#if USE_KEY
    lv_group_t *group = lv_port_indev_group_create();
#endif
    lv_obj_t * btn = lv_btn_create(setting_main_bg_obj);     /*Add a button the current screen*/
    lv_obj_set_style_outline_color(btn, outline_color, LV_STATE_FOCUS_KEY);
    //lv_obj_set_pos(btn, 10, 10);                            /*Set its position*/
    lv_obj_set_size(btn, 120, 50);                          /*Set its size*/
    lv_obj_add_event_cb(btn, btn0_event_cb, LV_EVENT_ALL, NULL);           /*Assign a callback to the button*/
    lv_obj_align(btn, LV_ALIGN_TOP_LEFT, 10, 10);

    lv_obj_t * label = lv_label_create(btn);          /*Add a label to the button*/
    lv_label_set_text(label, "Button");                     /*Set the labels text*/
    lv_obj_center(label);
#if USE_KEY
    lv_group_add_obj(group, btn);
#endif

    lv_obj_t *sw = lv_switch_create(lv_scr_act());
    lv_obj_set_style_outline_color(sw, outline_color, LV_STATE_FOCUS_KEY);
    lv_obj_set_size(sw, 60, 30);
    lv_obj_add_event_cb(sw, sw_event_handler, LV_EVENT_ALL, NULL);
    lv_obj_align(sw, LV_ALIGN_TOP_LEFT, 10, 70);
#if USE_KEY
    lv_group_add_obj(group, sw);
#endif

    btn = lv_btn_create(setting_main_bg_obj);     /*Add a button the current screen*/
    lv_obj_set_style_outline_color(btn, outline_color, LV_STATE_FOCUS_KEY);
    //lv_obj_set_pos(btn, 10, 10);                            /*Set its position*/
    lv_obj_set_size(btn, 120, 50);                          /*Set its size*/
    lv_obj_add_event_cb(btn, btn1_event_cb, LV_EVENT_ALL, NULL);           /*Assign a callback to the button*/
    lv_obj_align(btn, LV_ALIGN_TOP_LEFT, 10, 120);

    label = lv_label_create(btn);          /*Add a label to the button*/
    lv_label_set_text(label, "exit");                     /*Set the labels text*/
    lv_obj_center(label);
#if USE_KEY
    lv_group_add_obj(group, btn);
#endif
}

void setting_stop(void)
{
    if (setting_main_bg_obj) {
#if USE_KEY
        lv_group_t *group = lv_group_get_default();
        lv_port_indev_group_destroy(lv_group_get_default());
#endif
        lv_obj_del(setting_main_bg_obj);
        setting_main_bg_obj = NULL;
    }

    if (img_bg) {
        if (img_bg->data)
            free(img_bg->data);
        free(img_bg);
        img_bg = NULL;
    }
    if (pReturn_cb)
        pReturn_cb();
    pReturn_cb = NULL;
}