#ifndef __UI_MAIN_H__
#define __UI_MAIN_H__

void ui_start(int dev_id, int *run);

#endif
