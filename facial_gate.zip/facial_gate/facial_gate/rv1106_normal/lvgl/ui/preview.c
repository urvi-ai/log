#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>

#include <lvgl.h>
#include "lv_port_disp.h"
#include "lv_port_indev.h"
#include "key.h"
#include "preview.h"

extern int g_sensor_id;

static lv_img_dsc_t *img_bg = NULL;

static lv_obj_t *preview_main_obj = NULL;
static lv_obj_t *preview_main_bg_obj = NULL;
static void (*pReturn_cb)(void) = NULL;
static int sensor_dev_id = 0;

static lv_img_dsc_t *create_bg(void)
{
    int i, j;
    lv_img_dsc_t* img_res = NULL;
    int *buff;

    img_res = malloc(sizeof(lv_img_dsc_t));
    memset(img_res, 0, sizeof(lv_img_dsc_t));
    img_res->header.always_zero = 0;
    img_res->header.w = LV_HOR_RES;
    img_res->header.h = LV_VER_RES;
    img_res->data_size = LV_HOR_RES * LV_VER_RES * LV_IMG_PX_SIZE_ALPHA_BYTE;
    img_res->header.cf = LV_IMG_CF_TRUE_COLOR_ALPHA;
    img_res->data = malloc(img_res->data_size);
    buff = img_res->data;
    for (i = 0; i < img_res->header.w * img_res->header.h; i++) {
        buff[i] = 0x00000000;
    }

    return img_res;
}

static void btn0_event_cb(lv_event_t * e)
{
#if 0
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * btn = lv_event_get_target(e);
    if(code == LV_EVENT_CLICKED) {
        static uint8_t cnt = 0;
        cnt++;

        /*Get the first child of the button which is the label and change its text*/
        lv_obj_t * label = lv_obj_get_child(btn, 0);
        lv_label_set_text_fmt(label, "Button: %d", cnt);
    }
#endif
    int ret;
    lv_event_code_t code = lv_event_get_code(e);
    if(code == LV_EVENT_CLICKED) {
        preview_stop();
        g_sensor_id = g_sensor_id == 1 ? 0 : 1;
        preview_set_sensor_id(g_sensor_id);
        preview_start(NULL);
    }
}

static void btn1_event_cb(lv_event_t * e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * btn = lv_event_get_target(e);
    if(code == LV_EVENT_CLICKED) {
        preview_stop();
        setting_start(&preview_start);
    }
}

static void gpio_export(int num)
{
    char path[64];
    int fd = open("/sys/class/gpio/export", O_WRONLY);
    if (fd < 0) return;

    snprintf(path, sizeof(path), "%d", num);
    write(fd, path, strlen(path));
    close(fd);
}

static void gpio_set_direction(int num, const char *dir)
{
    char path[64];
    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/direction", num);
    int fd = open(path, O_WRONLY);
    if (fd < 0) return;

    write(fd, dir, strlen(dir));  // "out" or "in"
    close(fd);
}

static void gpio_output_value(int num, int value)
{
    char path[64];
    int fd;

    // 导出 GPIO
    gpio_export(num);
    usleep(100000);  // 等待 sysfs 生效

    // 设置方向为输出
    gpio_set_direction(num, "out");

    // 设置输出值
    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", num);
    fd = open(path, O_WRONLY);
    if (fd < 0) return;

    if (value)
        write(fd, "1", 1);
    else
        write(fd, "0", 1);

    close(fd);
}

static void btn2_event_cb(lv_event_t * e)
{
    int fl_led_gpio = 117; // 补光灯 GPIO
    int ir_led_gpio = 121; // 红外灯 GPIO

    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * btn = lv_event_get_target(e);

    static int state = 0; // 状态切换

    if (code == LV_EVENT_CLICKED) {
        state = !state;

        gpio_output_value(fl_led_gpio, state);  // 开关补光灯
        gpio_output_value(ir_led_gpio, !state); // 红外灯反向控制
    }
}

static void btn3_event_cb(lv_event_t * e)
{
    int releay_gpio = 145; // GPIO4_C1  4*32 + 8*2 + 1

    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * btn = lv_event_get_target(e);

    static int state = 0; // 状态切换

    if (code == LV_EVENT_CLICKED) {
        state = !state;

        gpio_output_value(releay_gpio, state);  // 开关补光灯
    }
}

void preview_start(void (*return_cb)(void))
{
    lv_obj_t *obj;
    lv_color_t bg_color;
    lv_color_t outline_color;
    bg_color.full = 0x00000000;
    outline_color.full = 0xffff0000;

    stVideoWin video_win;
    memset(&video_win, 0, sizeof(struct VideoWin));
    video_win.x = 0;
    video_win.y = 0;
    video_win.w = LV_HOR_RES;
    video_win.h = LV_VER_RES;
    video_win.Enable = 1;
    video_win.ViPipe = sensor_dev_id;
    video_win.ViChn = 1;

    lv_creat_video_win(1);
    lv_set_video_win(0, &video_win);

    pReturn_cb = return_cb;
    img_bg = create_bg();

    preview_main_obj = obj = lv_obj_create(lv_scr_act());
    lv_obj_set_size(obj, LV_HOR_RES , LV_VER_RES);
    lv_obj_align(obj, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_set_style_bg_color(obj, bg_color, 0);
    lv_obj_set_style_border_color(obj, bg_color, 0);
    lv_obj_set_style_radius(obj, 0, 0);

    preview_main_bg_obj = obj = lv_img_create(lv_scr_act());
    lv_img_set_src(obj, img_bg);
#if USE_KEY
    lv_group_t *group = lv_port_indev_group_create();
#endif
    lv_obj_t * btn = lv_btn_create(preview_main_bg_obj);     /*Add a button the current screen*/
    lv_obj_set_style_outline_color(btn, outline_color, LV_STATE_FOCUS_KEY);
    //lv_obj_set_pos(btn, 10, 10);                            /*Set its position*/
    lv_obj_set_size(btn, 120, 50);                          /*Set its size*/
    lv_obj_add_event_cb(btn, btn0_event_cb, LV_EVENT_ALL, NULL);           /*Assign a callback to the button*/
    lv_obj_align(btn, LV_ALIGN_BOTTOM_LEFT, 10, -10);

    lv_obj_t * label = lv_label_create(btn);          /*Add a label to the button*/
    lv_label_set_text(label, "Switch");                     /*Set the labels text*/
    lv_obj_center(label);
#if USE_KEY
    lv_group_add_obj(group, btn);
#endif

    btn = lv_btn_create(preview_main_bg_obj);     /*Add a button the current screen*/
    lv_obj_set_style_outline_color(btn, outline_color, LV_STATE_FOCUS_KEY);
    //lv_obj_set_pos(btn, 10, 10);                            /*Set its position*/
    lv_obj_set_size(btn, 120, 50);                          /*Set its size*/
    lv_obj_add_event_cb(btn, btn1_event_cb, LV_EVENT_ALL, NULL);           /*Assign a callback to the button*/
    lv_obj_align(btn, LV_ALIGN_BOTTOM_LEFT, 140, -10);

    label = lv_label_create(btn);          /*Add a label to the button*/
    lv_label_set_text(label, "setting");                     /*Set the labels text*/
    lv_obj_center(label);
    
    
    btn = lv_btn_create(preview_main_bg_obj);     /*Add a button the current screen*/
    lv_obj_set_style_outline_color(btn, outline_color, LV_STATE_FOCUS_KEY);
    //lv_obj_set_pos(btn, 10, 10);                            /*Set its position*/
    lv_obj_set_size(btn, 90, 50);                          /*Set its size*/
    lv_obj_add_event_cb(btn, btn2_event_cb, LV_EVENT_ALL, NULL);           /*Assign a callback to the button*/
    lv_obj_align(btn, LV_ALIGN_BOTTOM_LEFT, 270, -10);
    
    label = lv_label_create(btn);          /*Add a label to the button*/
    lv_label_set_text(label, "LED");                     /*Set the labels text*/
    lv_obj_center(label);
    
    btn = lv_btn_create(preview_main_bg_obj);     /*Add a button the current screen*/
    lv_obj_set_style_outline_color(btn, outline_color, LV_STATE_FOCUS_KEY);
    //lv_obj_set_pos(btn, 10, 10);                            /*Set its position*/
    lv_obj_set_size(btn, 90, 50);                          /*Set its size*/
    lv_obj_add_event_cb(btn, btn3_event_cb, LV_EVENT_ALL, NULL);           /*Assign a callback to the button*/
    lv_obj_align(btn, LV_ALIGN_BOTTOM_LEFT, 370, -10);
    
    label = lv_label_create(btn);          /*Add a label to the button*/
    lv_label_set_text(label, "RELAY");                     /*Set the labels text*/
    lv_obj_center(label);
    
#if USE_KEY
    lv_group_add_obj(group, btn);
#endif
}

void preview_stop(void)
{
    if (preview_main_bg_obj) {
        lv_obj_del(preview_main_bg_obj);
        preview_main_bg_obj = NULL;
    }
    if (preview_main_obj) {
#if USE_KEY
        lv_group_t *group = lv_group_get_default();
        lv_port_indev_group_destroy(lv_group_get_default());
#endif
        lv_obj_del(preview_main_obj);
        preview_main_obj = NULL;
    }
    if (img_bg) {
        if (img_bg->data)
            free(img_bg->data);
        free(img_bg);
        img_bg = NULL;
    }
    if (pReturn_cb)
        pReturn_cb();
    pReturn_cb = NULL;

    lv_destroy_all_video_win();
}

void preview_set_sensor_id(int dev_id)
{
    sensor_dev_id = dev_id;
}