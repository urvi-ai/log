#ifndef __SETTING_H__
#define __SETTING_H__

void setting_start(void (*return_cb)(void));
void setting_stop(void);

#endif
