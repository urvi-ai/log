#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <lvgl.h>
#include "drm_display.h"
#include "lv_port_disp.h"
#include "lv_port_indev.h"
#include "preview.h"
#include "setting.h"

#define LVGL_TICK    5
static int g_ui_rotation = 0;

static int lvgl_init(void)
{
    int ret = 0;

    lv_init();

    ret = lv_port_disp_init(g_ui_rotation);
    if (ret) {
        printf("lv_port_disp_init error\n");
        return ret;
    }

    lv_port_indev_init(g_ui_rotation);
    return ret;
}

static void lvgl_deinit(void)
{
    lv_port_disp_deinit();
}

void ui_start(int dev_id, int *run)
{
    if (lvgl_init())
        return;

    preview_set_sensor_id(dev_id);
    preview_start(NULL);
    while(*run) {
        lv_tick_inc(LVGL_TICK);
        lv_task_handler();
        usleep(LVGL_TICK * 1000);
    }
    preview_stop();
    lvgl_deinit();
}