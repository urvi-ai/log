#ifndef __DRM_DISPLAY_H__
#define __DRM_DISPLAY_H__

struct drm_bo {
    int fd;
    void *ptr;
    size_t size;
    size_t offset;
    size_t pitch;
    unsigned int handle;
    int fb_id;
    int buf_fd;
};

int drm_init(int bpp, int rot);
int drm_deinit(void);
void getdrmdispbuff(char **buff);
int getdrmdispinfo(struct drm_bo *bo, int *w, int *h);
struct drm_bo *getdrmdisp(void);
void setdrmdisp(struct drm_bo *bo);
int drm_setmode(int num, int bpp);
int drm_invalide(void);
void getdrmdispbpp(int *bpp);
void getdrmresolve(int *w, int *h);
void getdrmvideodispbuff(char **buff);
int getdrmvideodispinfo(struct drm_bo *bo, int *w, int *h);
struct drm_bo *getdrmvideodisp(void);
void setdrmvideodisp(struct drm_bo *bo);
void drmvideodispblack(void);
int getdrmwstride(void);
int getdrmvideowstride(void);
int getdrmrot(void);

int drm_screen_off(void);
int drm_screen_on(void);

void *drm_display_buf_alloc(int TexWidth, int TexHeight, int bpp, int *fd, int *handle, size_t *actual_size, int flags);
int drm_display_buf_destroy(int buf_fd, int handle, void *drm_buf, size_t size);

#endif
