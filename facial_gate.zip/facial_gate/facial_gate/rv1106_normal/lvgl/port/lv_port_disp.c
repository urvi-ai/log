/**
 * @file lv_port_disp_templ.c
 *
 */

 /*Copy this file as "lv_port_disp.c" and set this value to "1" to enable content*/

#include <pthread.h>
#include <stdlib.h>
#include <stdint.h>

#include <rga/rga.h>
#include <rga/im2d.h>

#include <rk_debug.h>
#include <rk_mpi_mb.h>
#include <rk_mpi_rgn.h>
#include <rk_mpi_sys.h>
#include <rk_mpi_venc.h>
#include <rk_mpi_vi.h>
#include <rk_mpi_vpss.h>

#include "lv_port_disp.h"
#include <lvgl.h>

#include "drm_display.h"
#include "rockit.h"

static int rot_disp = 90;
static int lcd_w;
static int lcd_h;
static int lcd_sw;
static char* ui_buff;
static int ui_buff_fd;
static int ui_buff_handle;
static int ui_buff_size;
static lv_color_t *buf_1;

static pthread_mutex_t video_win_mutex;
static int video_win_num;
static struct VideoWin* video_wins = NULL;
    
extern int g_sensor_rotation;

//static struct timeval tvCbBegin;
//static struct timeval tvCbEnd;
static int quit = 0;
static pthread_t disp_thread_pid;
static pthread_mutex_t draw_mutex;
static int draw_update = 0;
static int pipe_id_ = 0;

#define VIDEO_PIPE_0 0
#define VIDEO_PIPE_1 1
#define VIDEO_PIPE_2 2
#define ROTATE_USE_RGA

static int disp_init(void);

static void disp_flush(lv_disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p);

int lv_creat_video_win(int num)
{
    int ret = -1;
    pthread_mutex_lock(&video_win_mutex);
    if (video_wins)
        free(video_wins);
    if (num > 0) {
        video_wins = malloc(num * sizeof(struct VideoWin));
        if (video_wins) {
            ret = 0;
            memset(video_wins, 0, num * sizeof(struct VideoWin));
            video_win_num = num;
        }
    }
    pthread_mutex_unlock(&video_win_mutex);
}

void lv_destroy_all_video_win(void)
{
    pthread_mutex_lock(&video_win_mutex);
    if (video_wins)
        free(video_wins);
    video_win_num = 0;
    video_wins = NULL;
    pthread_mutex_unlock(&video_win_mutex);
}

int lv_get_video_win_num(void)
{
    int ret;

    pthread_mutex_lock(&video_win_mutex);
    ret = video_win_num;
    pthread_mutex_unlock(&video_win_mutex);

    return ret;
}

int lv_get_video_win(int chn, stVideoWin* video_win)
{
    int ret = -1;

    pthread_mutex_lock(&video_win_mutex);
    if (chn < video_win_num && video_win && video_wins) {
        ret = 0;
        memcpy(video_win, &video_wins[chn], sizeof(struct VideoWin));
    }
    pthread_mutex_unlock(&video_win_mutex);

    return ret;
}

int lv_set_video_win(int chn, stVideoWin* video_win)
{
    int ret = -1;

    pthread_mutex_lock(&video_win_mutex);
    if (chn < video_win_num && video_win && video_wins) {
        ret = 0;
        memcpy(&video_wins[chn], video_win, sizeof(struct VideoWin));
    }
    pthread_mutex_unlock(&video_win_mutex);

    return ret;
}

static void disp_thread_stop(void)
{
    quit = 1;
}

static void *disp_thread(void *arg)
{
    while (!quit) {
        VIDEO_FRAME_INFO_S stViFrame;
        VIDEO_FRAME_INFO_S stVpssFrame;
        VI_CHN_STATUS_S stChnStatus;
        
        int video_en = 0;
        int i;
        int ret;

        pthread_mutex_lock(&video_win_mutex);
        for (i = 0; i < video_win_num; i++) {
            if (video_wins[i].Enable)
                video_en = 1;
        }
        pthread_mutex_unlock(&video_win_mutex);

        if (video_en == 0) {
            pthread_mutex_lock(&draw_mutex);
            if (rot_disp == 0) {
#ifdef USE_DRM
                struct drm_bo *bo = getdrmdisp();
                int disp_fd = bo->buf_fd;
#endif
#ifdef USE_VO
                int vo_fd = rockit_get_vo_fd(1);
                int disp_fd = vo_fd;
                VIDEO_FRAME_INFO_S stVFrame = rockit_get_vo_frame(1);
#endif

                struct im_handle_param src_param = {lcd_w, lcd_h, RK_FORMAT_BGRA_8888};
                struct im_handle_param dts_param = {lcd_w, lcd_h, RK_FORMAT_BGRA_8888};
                rga_buffer_handle_t src_handle = importbuffer_fd(ui_buff_fd, &src_param);
                rga_buffer_handle_t dst_handle = importbuffer_fd(disp_fd, &dts_param);
                rga_buffer_t src = wrapbuffer_handle(src_handle, lcd_w, lcd_h, RK_FORMAT_BGRA_8888, lcd_w, lcd_h);
                rga_buffer_t dst = wrapbuffer_handle(dst_handle, lcd_w, lcd_h, RK_FORMAT_BGRA_8888, lcd_w, lcd_h);
                IM_STATUS ret = imblend(src, dst, IM_ALPHA_BLEND_SRC_OVER, 1);
                if ((IM_STATUS_NOERROR != ret) && (IM_STATUS_SUCCESS != ret))
                    printf("%d, check error! %s\n", __LINE__, imStrError(ret));
                releasebuffer_handle(src_handle);
                releasebuffer_handle(dst_handle);

#ifdef USE_DRM
                setdrmdisp(bo);
#endif
#ifdef USE_VO
                ret = RK_MPI_VO_SendFrame(0, 0, &stVFrame, 1000);
                if (ret)
                    printf("RK_MPI_VO_SendFrame timeout %x\n", ret);
#endif
            }
            pthread_mutex_unlock(&draw_mutex);
            usleep(17000);
        } else {
            if (rot_disp == 0) {
                pthread_mutex_lock(&video_win_mutex);
                if (video_win_num == 1 && video_wins->x == 0 && video_wins->y == 0 && video_wins->w == lcd_w && video_wins->h == lcd_h) {
                    ret = RK_MPI_VI_GetChnFrame(video_wins->ViPipe, video_wins->ViChn, &stViFrame, 1000);
                    if (ret == RK_SUCCESS) {
                        int32_t fd = RK_MPI_MB_Handle2Fd(stViFrame.stVFrame.pMbBlk);

                        ret = RK_MPI_VI_QueryChnStatus(video_wins->ViPipe, video_wins->ViChn, &stChnStatus);
                        if (ret != RK_SUCCESS)
                            printf("RK_MPI_VI_QueryChnStatus fail %x\n", ret);
                        pthread_mutex_lock(&draw_mutex);

#ifdef USE_DRM
                        struct drm_bo *bo = getdrmdisp();
                        int disp_fd = bo->buf_fd;
#endif
#ifdef USE_VO
                        int vo_fd = rockit_get_vo_fd(1);
                        int disp_fd = vo_fd;
                        VIDEO_FRAME_INFO_S stVFrame = rockit_get_vo_frame(1);
#endif
                        struct im_handle_param src_param = {stChnStatus.stSize.u32Width, stChnStatus.stSize.u32Height, RK_FORMAT_YCbCr_420_SP};
                        struct im_handle_param dts_param = {lcd_w, lcd_h, RK_FORMAT_BGRA_8888};
                        struct im_handle_param ui_param = {lcd_w, lcd_h, RK_FORMAT_BGRA_8888};
                        
                        rga_buffer_handle_t src_handle = importbuffer_fd(fd, &src_param);
                        rga_buffer_handle_t dst_handle = importbuffer_fd(disp_fd, &dts_param);
                        rga_buffer_handle_t ui_handle = importbuffer_fd(ui_buff_fd, &ui_param);
                        
                        rga_buffer_t src = wrapbuffer_handle(src_handle, stChnStatus.stSize.u32Width, stChnStatus.stSize.u32Height,
                                                             RK_FORMAT_YCbCr_420_SP, stChnStatus.stSize.u32Width, stChnStatus.stSize.u32Height);
                        rga_buffer_t dst = wrapbuffer_handle(dst_handle, lcd_w, lcd_h, RK_FORMAT_BGRA_8888, lcd_w, lcd_h);
                        rga_buffer_t ui = wrapbuffer_handle(ui_handle, lcd_w, lcd_h, RK_FORMAT_BGRA_8888, lcd_w, lcd_h);
                        
                        
#ifdef ROTATE_USE_RGA
                        if(!(g_sensor_rotation == IM_HAL_TRANSFORM_ROT_90 ||
                                g_sensor_rotation == IM_HAL_TRANSFORM_ROT_180 ||
                                g_sensor_rotation == IM_HAL_TRANSFORM_ROT_270))
                            goto skip_rga_rotate;
                        
                        MB_BLK pMblk;
                        int32_t rotate_fd;
                        RK_S32 s32Ret = RK_SUCCESS;
                        PIC_BUF_ATTR_S stPicBufAttr;
                        MB_PIC_CAL_S stMbPicCalResult;
                        rga_buffer_t rotate_dst;

                        stPicBufAttr.u32Width = stChnStatus.stSize.u32Width;
                        stPicBufAttr.u32Height = stChnStatus.stSize.u32Height;
                        stPicBufAttr.enPixelFormat = RK_FMT_YUV420SP;
                        stPicBufAttr.enCompMode = COMPRESS_MODE_NONE;
                        s32Ret = RK_MPI_CAL_COMM_GetPicBufferSize(&stPicBufAttr, &stMbPicCalResult); // Calculate the required memory size

                        if (s32Ret != RK_SUCCESS) {
                            RK_LOGE("get picture buffer size failed. err 0x%x", s32Ret);
                            return s32Ret;
                        }
                        
                        ret = RK_MPI_SYS_MmzAlloc(&pMblk, RK_NULL, RK_NULL, stMbPicCalResult.u32MBSize);
                        if (ret != RK_SUCCESS) {
                            printf("%d, RK_MPI_SYS_MmzAlloc failed! %s\n", ret, __func__);
                        }
                        
                        rotate_fd = RK_MPI_MB_Handle2Fd(pMblk);
                        
                        struct im_handle_param rotate_param = {stChnStatus.stSize.u32Height, stChnStatus.stSize.u32Width, RK_FORMAT_YCbCr_420_SP};
                        rga_buffer_handle_t rotate_handle = importbuffer_fd(rotate_fd, &rotate_param);
                        
                        //Rotate 90 or 270, and the width and height need to be exchanged.
                        if(g_sensor_rotation == IM_HAL_TRANSFORM_ROT_90 || g_sensor_rotation == IM_HAL_TRANSFORM_ROT_270){
                            rotate_dst = wrapbuffer_handle(rotate_handle, stChnStatus.stSize.u32Height, stChnStatus.stSize.u32Width,
                                                             RK_FORMAT_YCbCr_420_SP, stChnStatus.stSize.u32Height, stChnStatus.stSize.u32Width);
                        }else{
                            rotate_dst = wrapbuffer_handle(rotate_handle, stChnStatus.stSize.u32Width, stChnStatus.stSize.u32Height,
                                                             RK_FORMAT_YCbCr_420_SP, stChnStatus.stSize.u32Width, stChnStatus.stSize.u32Height);
                        }
                        ret = imrotate(src, rotate_dst, g_sensor_rotation);
                        if (ret != IM_STATUS_SUCCESS) {
                            printf("%d, imrotate failed! %s\n", __LINE__, imStrError((IM_STATUS)ret));
                        }
                        
                        IM_STATUS ret = imcomposite(rotate_dst, ui, dst, IM_ALPHA_BLEND_DST_OVER, 1);
                        if ((IM_STATUS_NOERROR != ret) && (IM_STATUS_SUCCESS != ret))
                            printf("%d, check error! %s\n", __LINE__, imStrError(ret));
skip_rga_rotate:
#else

                        IM_STATUS ret = imcomposite(src, ui, dst, IM_ALPHA_BLEND_DST_OVER, 1);
                        if ((IM_STATUS_NOERROR != ret) && (IM_STATUS_SUCCESS != ret))
                            printf("%d, check error! %s\n", __LINE__, imStrError(ret));
#endif
                        releasebuffer_handle(src_handle);
                        releasebuffer_handle(dst_handle);
                        releasebuffer_handle(ui_handle);

#ifdef USE_DRM
                        setdrmdisp(bo);
#endif
#ifdef USE_VO
                        ret = RK_MPI_VO_SendFrame(0, 0, &stVFrame, 1000);
                        if (ret)
                            printf("RK_MPI_VO_SendFrame timeout %x\n", ret);
#endif

                        pthread_mutex_unlock(&draw_mutex);

                        ret = RK_MPI_VI_ReleaseChnFrame(video_wins->ViPipe, video_wins->ViChn, &stViFrame);
                        if (ret != RK_SUCCESS)
                            printf("RK_MPI_VI_ReleaseChnFrame fail %x\n", ret);
#ifdef ROTATE_USE_RGA
                        releasebuffer_handle(rotate_handle);
                        ret = RK_MPI_SYS_MmzFree(pMblk);
                        if (ret != RK_SUCCESS)
                            printf("RK_MPI_SYS_MmzFree fail %x\n", ret);
#endif
                    }
                    pthread_mutex_unlock(&video_win_mutex);
                    usleep(1000);
	            } else {
#ifdef USE_DRM
                    struct drm_bo *bo = getdrmdisp();
                    int disp_fd = bo->buf_fd;
#endif
#ifdef USE_VO
                    int vo_fd = rockit_get_vo_fd(1);
                    int disp_fd = vo_fd;
                    VIDEO_FRAME_INFO_S stVFrame = rockit_get_vo_frame(1);
#endif
                    for (i = 0; i < video_win_num; i++) {
                        if (video_wins[i].Enable) {
                            ret = RK_MPI_VI_GetChnFrame(video_wins[i].ViPipe, video_wins[i].ViChn, &stViFrame, 1000);
                            if (ret == RK_SUCCESS) {
                                int32_t fd = RK_MPI_MB_Handle2Fd(stViFrame.stVFrame.pMbBlk);
                                ret = RK_MPI_VI_QueryChnStatus(video_wins[i].ViPipe, video_wins[i].ViChn, &stChnStatus);
                                if (ret != RK_SUCCESS)
                                    printf("RK_MPI_VI_QueryChnStatus fail %x\n", ret);

                                struct im_handle_param src_param = {stChnStatus.stSize.u32Width, stChnStatus.stSize.u32Height, RK_FORMAT_YCbCr_420_SP};
                                struct im_handle_param dts_param = {lcd_w, lcd_h, RK_FORMAT_BGRA_8888};
                                rga_buffer_handle_t src_handle = importbuffer_fd(fd, &src_param);
                                rga_buffer_handle_t dst_handle = importbuffer_fd(disp_fd, &dts_param);
                                rga_buffer_t src = wrapbuffer_handle(src_handle, stChnStatus.stSize.u32Width, stChnStatus.stSize.u32Height,
                                                                     RK_FORMAT_YCbCr_420_SP, stChnStatus.stSize.u32Width, stChnStatus.stSize.u32Height);
                                rga_buffer_t dst = wrapbuffer_handle(dst_handle, lcd_w, lcd_h, RK_FORMAT_BGRA_8888, lcd_w, lcd_h);
                                IM_STATUS ret = imblend(src, dst, IM_ALPHA_BLEND_SRC, 1);
                                if ((IM_STATUS_NOERROR != ret) && (IM_STATUS_SUCCESS != ret))
                                    printf("%d, check error! %s\n", __LINE__, imStrError(ret));
                                releasebuffer_handle(src_handle);
                                releasebuffer_handle(dst_handle);

                                ret = RK_MPI_VI_ReleaseChnFrame(video_wins[i].ViPipe, video_wins[i].ViChn, &stViFrame);
                                if (ret != RK_SUCCESS)
                                    printf("RK_MPI_VI_ReleaseChnFrame fail %x\n", ret);
                            }
                        }
                    }
                    pthread_mutex_unlock(&video_win_mutex);
                    pthread_mutex_lock(&draw_mutex);

                    struct im_handle_param src_param = {lcd_w, lcd_h, RK_FORMAT_BGRA_8888};
                    struct im_handle_param dts_param = {lcd_w, lcd_h, RK_FORMAT_BGRA_8888};
                    rga_buffer_handle_t src_handle = importbuffer_fd(ui_buff_fd, &src_param);
                    rga_buffer_handle_t dst_handle = importbuffer_fd(disp_fd, &dts_param);
                    rga_buffer_t src = wrapbuffer_handle(src_handle, lcd_w, lcd_h, RK_FORMAT_BGRA_8888, lcd_w, lcd_h);
                    rga_buffer_t dst = wrapbuffer_handle(dst_handle, lcd_w, lcd_h, RK_FORMAT_BGRA_8888, lcd_w, lcd_h);
                    IM_STATUS ret = imblend(src, dst, IM_ALPHA_BLEND_SRC_OVER, 1);
                    if ((IM_STATUS_NOERROR != ret) && (IM_STATUS_SUCCESS != ret))
                        printf("%d, check error! %s\n", __LINE__, imStrError(ret));
                    releasebuffer_handle(src_handle);
                    releasebuffer_handle(dst_handle);

                    pthread_mutex_unlock(&draw_mutex);
#ifdef USE_DRM
                    setdrmdisp(bo);
#endif
#ifdef USE_VO
                    ret = RK_MPI_VO_SendFrame(0, 0, &stVFrame, 1000);
                    if (ret)
                         printf("RK_MPI_VO_SendFrame timeout %x\n", ret);
#endif
                }
            }
        }
    }

    return NULL;
}

int lv_port_disp_init(int rot)
{
    int ret = 0;

    rot_disp = rot;
    /*-------------------------
     * Initialize your display
     * -----------------------*/
    ret = disp_init();
    if (ret) {
        printf("disp_init error\n");
        return ret;
    }

    /*-----------------------------
     * Create a buffer for drawing
     *----------------------------*/

    /**
     * LVGL requires a buffer where it internally draws the widgets.
     * Later this buffer will passed to your display driver's `flush_cb` to copy its content to your display.
     * The buffer has to be greater than 1 display row
     *
     * There are 3 buffering configurations:
     * 1. Create ONE buffer:
     *      LVGL will draw the display's content here and writes it to your display
     *
     * 2. Create TWO buffer:
     *      LVGL will draw the display's content to a buffer and writes it your display.
     *      You should use DMA to write the buffer's content to the display.
     *      It will enable LVGL to draw the next part of the screen to the other buffer while
     *      the data is being sent form the first buffer. It makes rendering and flushing parallel.
     *
     * 3. Double buffering
     *      Set 2 screens sized buffers and set disp_drv.full_refresh = 1.
     *      This way LVGL will always provide the whole rendered screen in `flush_cb`
     *      and you only need to change the frame buffer's address.
     */

    /* Example for 1) */
    static lv_disp_draw_buf_t draw_buf_dsc_1;
    buf_1 = malloc(lcd_w * lcd_h * 4);
    if (!buf_1) {
        printf("malloc size %d error\n", lcd_w * lcd_h * 4);
        ret = -1;
        return ret;
    }

    lv_disp_draw_buf_init(&draw_buf_dsc_1, buf_1, NULL, lcd_w * lcd_h);   /*Initialize the display buffer*/

    /*-----------------------------------
     * Register the display in LVGL
     *----------------------------------*/

    static lv_disp_drv_t disp_drv;                         /*Descriptor of a display driver*/
    lv_disp_drv_init(&disp_drv);                    /*Basic initialization*/

    /*Set up the functions to access to your display*/

    /*Set the resolution of the display*/
    if (rot_disp == 0) {
        disp_drv.hor_res = lcd_w;
        disp_drv.ver_res = lcd_h;

        disp_drv.sw_rotate = 0;
        disp_drv.rotated = LV_DISP_ROT_NONE;
    } else if (rot_disp == 180) {
        disp_drv.hor_res = lcd_w;
        disp_drv.ver_res = lcd_h;

        disp_drv.sw_rotate = 1;
        disp_drv.rotated = LV_DISP_ROT_180;
    } else if (rot_disp == 90) {
        disp_drv.hor_res = lcd_h;
        disp_drv.ver_res = lcd_w;

        disp_drv.sw_rotate = 0;
        disp_drv.rotated = LV_DISP_ROT_NONE;
    } else if (rot_disp == 270) {
        disp_drv.hor_res = lcd_h;
        disp_drv.ver_res = lcd_w;

        disp_drv.sw_rotate = 1;
        disp_drv.rotated = LV_DISP_ROT_180;
    }
    /*Used to copy the buffer's content to the display*/
    disp_drv.flush_cb = disp_flush;

    /*Set a display buffer*/
    disp_drv.draw_buf = &draw_buf_dsc_1;

    /*Required for Example 3)*/
    //disp_drv.full_refresh = 1

    /*Finally register the driver*/
    lv_disp_drv_register(&disp_drv);
    pthread_mutex_init(&draw_mutex, NULL);
    pthread_mutex_init(&video_win_mutex, NULL);
    pthread_create(&disp_thread_pid, NULL, disp_thread, NULL);
    return ret;
}

/*Initialize your display and the required peripherals.*/
static int disp_init(void)
{
#ifdef USE_DRM
    int bpp = 32;
    /*You code here*/
    drm_init(bpp, rot_disp);
    getdrmresolve(&lcd_w, &lcd_h);
    lcd_sw = getdrmwstride();
    ui_buff = drm_display_buf_alloc(lcd_w, lcd_h, bpp, &ui_buff_fd, &ui_buff_handle, &ui_buff_size, 0);
    if (!ui_buff) {
        printf("drm_display_buf_alloc error\n");
        return -1;
    }
#endif

#ifdef USE_VO
    void *handle;

    rockit_get_vo_resolve(1, &lcd_w, &lcd_h);
    lcd_sw = lcd_w;

    ui_buff_size = RK_MPI_VO_CreateGraphicsFrameBuffer(lcd_w, lcd_h, RK_FMT_BGRA8888, &handle);
    if (ui_buff_size == 0) {
        printf("can not create graphics frame buffer\n");
        return -1;
    }
    ui_buff_fd = RK_MPI_MB_Handle2Fd(handle);
    if (ui_buff_fd < 0) {
        printf("RK_MPI_MB_Handle2Fd fail!\n");
        return -1;
    }
    ui_buff = RK_MPI_MB_Handle2VirAddr(handle);
    if (ui_buff == NULL) {
        printf("RK_MPI_MB_Handle2VirAddr fail!\n");
        return -1;
    }
#endif
    return 0;
}

static void disp_deinit(void)
{
#ifdef USE_DRM
    drm_display_buf_destroy(ui_buff_fd, ui_buff_handle, ui_buff, ui_buff_size);
#endif

#ifdef USE_VO
    void *handle = RK_MPI_MB_VirAddr2Handle(ui_buff);
    RK_MPI_VO_DestroyGraphicsFrameBuffer(handle);
#endif
}

void lv_port_disp_deinit(void)
{
    disp_thread_stop();
    disp_deinit();

    if (buf_1)
        free(buf_1);
}

/*Flush the content of the internal buffer the specific area on the display
 *You can use DMA or any hardware acceleration to do this operation in the background but
 *'lv_disp_flush_ready()' has to be called when finished.*/
static void disp_flush(lv_disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p)
{
    /*The most simple case (but also the slowest) to put all pixels to the screen one-by-one*/
    int32_t x;
    int32_t y;

    //printf("%s, x1 = %d, y1 = %d, x2 = %d, y2 = %d, %d, %d\n\n\n", __func__, area->x1, area->y1, area->x2, area->y2, area->x2 - area->x1 + 1, area->y2 - area->y1 + 1);
    //gettimeofday(&tvCbBegin, NULL);
    pthread_mutex_lock(&draw_mutex);
    if (rot_disp == 90 || rot_disp == 270) {
        for(y = area->y1; y <= area->y2; y++) {
            int area_w = area->x2 - area->x1 + 1;
            lv_color_t *disp = (lv_color_t*)(ui_buff + (y * lcd_h + area->x1) * 4);
            memcpy(disp, color_p, area_w * 4);
            color_p += area_w;
        }
    } else {
        for(y = area->y1; y <= area->y2; y++) {
            int area_w = area->x2 - area->x1 + 1;
            lv_color_t *disp = (lv_color_t*)(ui_buff + (y * lcd_w + area->x1) * 4);
            memcpy(disp, color_p, area_w * 4);
            color_p += area_w;
        }
    }
    draw_update = 1;
    pthread_mutex_unlock(&draw_mutex);
    //gettimeofday(&tvCbEnd, NULL);
    //double dDuration = 1000 * (tvCbEnd.tv_sec - tvCbBegin.tv_sec) + ((tvCbEnd.tv_usec - tvCbBegin.tv_usec) / 1000.0);
    //printf("%s dDuration = %f\n", __func__, dDuration);
    /*IMPORTANT!!!
     *Inform the graphics library that you are ready with the flushing*/
    lv_disp_flush_ready(disp_drv);
}
