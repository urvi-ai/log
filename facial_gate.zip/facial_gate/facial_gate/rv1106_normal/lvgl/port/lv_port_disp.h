/**
 * @file lv_port_disp_templ.h
 *
 */

 /*Copy this file as "lv_port_disp.h" and set this value to "1" to enable content*/

#ifndef LV_PORT_DISP_TEMPL_H
#define LV_PORT_DISP_TEMPL_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct VideoWin {
    int x;
    int y;
    int w;
    int h;
    char Enable;
    int ViPipe;
    int ViChn;
} stVideoWin;

int lv_port_disp_init(int rot);
int lv_creat_video_win(int num);
void lv_destroy_all_video_win(void);
int lv_get_video_win_num(void);
int lv_get_video_win(int chn, stVideoWin* video_win);
int lv_set_video_win(int chn, stVideoWin* video_win);
void lv_port_disp_deinit(void);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /*LV_PORT_DISP_TEMPL_H*/
