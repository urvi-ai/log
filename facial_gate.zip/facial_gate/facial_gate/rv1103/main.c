// Copyright 2022 Rockchip Electronics Co., Ltd. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <signal.h>
#include "isp.h"
#include "rockit.h"

static int g_main_run_ = 1;

static void sig_proc(int signo) {
    RK_LOGE("received signo %d \n", signo);
    g_main_run_ = 0;
}

int main(int argc, char *argv[]) {
    int dev_id = 0;
    char *param_ini_path = NULL; // use default param init file
    pthread_t uvc_thread = 0;
    pthread_t rtsp_thread = 0;

    signal(SIGINT, sig_proc);

    if (RK_MPI_SYS_Init() != RK_SUCCESS) {
        return -1;
    }

    rk_isp_init(dev_id, IQFILE_PATH);

    rk_param_init(param_ini_path);

    pthread_create(&rtsp_thread, 0, (void *)rockit_pipe_rtsp_start, NULL);

    pthread_create(&uvc_thread, 0, (void *)uvc_start, NULL);

    while (g_main_run_) {
        usleep(1000 * 1000);
    }

    uvc_stop();
    rockit_pipe_rtsp_stop();
    pthread_join(rtsp_thread, NULL);
    pthread_join(uvc_thread, NULL);

    rk_param_deinit();
    rk_isp_deinit(dev_id);
    RK_MPI_SYS_Exit();

    return RK_SUCCESS;
}
